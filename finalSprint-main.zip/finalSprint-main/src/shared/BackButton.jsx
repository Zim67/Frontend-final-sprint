import { Link } from "react-router-dom";

const BackButton = () => {
  return (
<<<<<<< HEAD
    <Link to="/">
=======
    <Link to="/products">
>>>>>>> 5307602c7b1442dc24372158f4ae0cee602e7457
      <button className="btn1">Go Back</button>
    </Link>
  );
};

export default BackButton;
