Link to figma design: https://www.figma.com/file/IiBjlynF9XhQahIMRX2dLN/Untitled?type=design&node-id=0%3A1&mode=design&t=4VogRdcqgoXbqPPW-1
