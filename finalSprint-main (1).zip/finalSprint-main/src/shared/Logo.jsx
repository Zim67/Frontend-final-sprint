const Logo = () => {
  return (
    <div className="logo">
      <h1>Pens</h1>
      <h4>of</h4>
      <h4>Haute Culture</h4>
    </div>
  );
};

export default Logo;
