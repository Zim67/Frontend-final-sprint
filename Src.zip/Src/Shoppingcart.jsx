import React from 'react';
import { useParams } from 'react-router-dom';
import { getProductById } from './api';

function ProductDetails() {
  const { productId } = useParams();
  const product = getProductById(Number(productId));

  return (
    <div>
      <h2>Product Details</h2>
      <h3>{product.name}</h3>
      <p>{product.description}</p>
      <p>Price: ${product.price}</p>
    </div>
  );
}

export default ProductDetails;
