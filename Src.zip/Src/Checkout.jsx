import React from 'react';
import { useShoppingCartContext } from './ShoppingCartContext';

function Checkout() {
  const { cartItems } = useShoppingCartContext();

  const totalAmount = cartItems.reduce((total, item) => total + item.price, 0);

  return (
    <div>
      <h2>Checkout</h2>
      <p>Total Amount: ${totalAmount}</p>
      {/* Add checkout form */}
    </div>
  );
}

export default Checkout;